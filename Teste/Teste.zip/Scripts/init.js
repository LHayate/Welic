﻿(function ($) {
    $(function () {

        $('.button-collapse').sideNav();
        $('.parallax').parallax();
        $('.modal').modal();
        

    }); // end of document ready
})(jQuery); // end of jQuery name space